﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentsCourseStructureApp.Entities
{
    public class Students
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, Display(Name = "First name")]
        [StringLength(50, ErrorMessage = " First name cannot be longer than 50 characters")]
        public string FirstMidName { get; set; }

        [Required, Display(Name = "Last name")]
        [StringLength(50)]
        public string LastName { get; set; }

        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0: dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime Age { get; set; }

        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0: dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime EnrollmentDate { get; set; }

        //navigation
        public ICollection<Courses> Courses { get; set; }

    }
}
