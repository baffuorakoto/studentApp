﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentsCourseStructureApp.Entities
{
    public class Subjects
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }
        [Required, Display(Name = "Subject title")]
        public string SubjectTitle { get; set; }

        [DataType(DataType.Time), DisplayFormat(DataFormatString = "{0: dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime Time { get; set; }


        public DayOfWeek Day;

        [ForeignKey("CourseFk")]
        public Courses Course { get; set; }
        public int CourseFk { get; set; }
    }
}
