﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentsCourseStructureApp.Entities
{
    public class Courses
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, Display(Name = "Course title")]
        public string Title { get; set; }



        //navigation


        public ICollection<Subjects> Subjects { get; set; }

        [ForeignKey("Students")]
        public int StudentsFk { get; set; }

        public Students Students { get; set; }



    }
}
