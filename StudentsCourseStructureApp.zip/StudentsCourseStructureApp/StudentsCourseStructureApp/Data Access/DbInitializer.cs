﻿using StudentsCourseStructureApp.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StudentsCourseStructureApp.Data_Access
{
    public class DbInitializer
    {
        private SchoolDbContext _ctx;

        public DbInitializer(SchoolDbContext ctx)
        {
            _ctx = ctx;
        }

        public void Seed()
        {


            if (!_ctx.Students.Any())
            {
                List<Students> students = new List<Students>
                {
                    new Students
                    {

                        Age = DateTime.Parse("2000,5,14"),
                        FirstMidName = "Dorcas Baffour",
                        LastName = "Addai",
                        EnrollmentDate = DateTime.Now,
                        Courses = new List<Courses>
                        {
                            new Courses
                            {
                                Title = "Computer Science",
                                Subjects = new List<Subjects>
                                {
                                    new Subjects
                            {

                                SubjectTitle = "Hardware",
                                Day = DayOfWeek.Wednesday,
                                Time = DateTime.Parse("7:20")
                            },

                            new Subjects
                            {

                                SubjectTitle = "Server 2012",
                                Day = DayOfWeek.Tuesday,
                                Time = DateTime.Parse("8:22")
                            },

                            new Subjects
                            {

                                SubjectTitle = "Microsoft Access",
                                Day = DayOfWeek.Thursday,
                                Time =DateTime.Parse("8:15")
                            },

                            new Subjects
                            {

                                SubjectTitle = "Excel",
                                Day = DayOfWeek.Monday,
                                Time =DateTime.Parse("8:29")
                            }
                                }
                            }
                        }
                    },


                    new Students
                    {

                        Age = DateTime.Parse("1990,5,14"),
                        FirstMidName = "Prince Awuah Baffour",
                        LastName = "Addai",
                        EnrollmentDate = DateTime.Now,
                        Courses = new List<Courses>
                        {
                            new Courses
                            {
                                Title = "Systems Engineering",
                                Subjects = new List<Subjects>
                                {
                                    new Subjects
                                    {
                                        SubjectTitle = "Rules of engagement",
                                        Day = DayOfWeek.Friday,
                                        Time = DateTime.Parse("10:32")
                                    },
                                    new Subjects
                                    {
                                        SubjectTitle = "Hardware",
                                        Day = DayOfWeek.Saturday,
                                        Time = DateTime.Parse("12:00"),

                                    },
                                    new Subjects
                                    {
                                        SubjectTitle = "Networking",
                                        Day = DayOfWeek.Thursday,
                                        Time = DateTime.Parse("11: 00")
                                    },
                                    new Subjects
                                    {
                                        SubjectTitle = "Windows Server 2012",
                                        Day = DayOfWeek.Tuesday,
                                        Time = DateTime.Parse("2:33")
                                    }
                                }
                            }
                        }

                    },

                    new Students
                    {

                        Age = DateTime.Parse("1992,5,14"),
                        FirstMidName = "Gordon Baffour",
                        LastName = "Addai",
                        EnrollmentDate = DateTime.Now,
                        Courses = new List<Courses>
                        {
                            new Courses
                            {
                                Title = "Accounting",
                                Subjects = new List<Subjects>
                                {
                                    new Subjects
                                    {
                                        SubjectTitle = "Marketing Basics",
                                        Day = DayOfWeek.Wednesday,
                                        Time = DateTime.Parse("3:15")
                                    },
                                    new Subjects
                                    {
                                        SubjectTitle = "Elective Math",
                                        Day = DayOfWeek.Monday,
                                        Time = DateTime.Parse("12:15")
                                    },
                                    new Subjects
                                    {
                                        SubjectTitle = "English",
                                        Day = DayOfWeek.Sunday,
                                        Time  = DateTime.Parse("4:44")
                                    }
                                }
                            }
                        }
                    },


                };
                _ctx.AddRange(students);
            }


            _ctx.SaveChanges();
        }
    }
}
