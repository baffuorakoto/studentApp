﻿using Microsoft.EntityFrameworkCore;
using StudentsCourseStructureApp.Entities;

namespace StudentsCourseStructureApp.Data_Access
{
    public class SchoolDbContext : DbContext
    {

        public SchoolDbContext(DbContextOptions<SchoolDbContext> options) : base(options)
        {

        }
        public DbSet<Students> Students { get; set; }
        public DbSet<Courses> Courses { get; set; }
        public DbSet<Subjects> Subjects { get; set; }


        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SchoolDbContext;Integrated Security=True;");

        //}
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Courses>().HasOne(c => c.Students).WithMany(c => c.Courses);
            modelBuilder.Entity<Subjects>().HasOne(c => c.Course).WithMany(s => s.Subjects);



        }
    }
}
