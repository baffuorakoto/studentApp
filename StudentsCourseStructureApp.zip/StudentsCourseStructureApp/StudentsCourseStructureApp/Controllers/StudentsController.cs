﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentsCourseStructureApp.Data_Access;
using StudentsCourseStructureApp.Entities;
using System;
using System.Linq;

namespace StudentsCourseStructureApp.Controllers
{

    [Route("api/[controller]")]
    public class StudentsController : Controller
    {
        private readonly SchoolDbContext _context;
        public StudentsController(SchoolDbContext context)
        {
            _context = context;
        }

        [HttpGet("", Name = "GetStudents")]
        public IActionResult Get()
        {
            var students = _context.Students.ToList();

            return Ok(students);

        }

        [HttpGet("{id}")]
        public IActionResult Get(int id, bool includeCourses = false)
        {

            Students student = null;

            if (includeCourses)
            {
                student = _context.Students.Include(c => c.Courses)
                .ThenInclude(s => s.Subjects)
                .Where(c => c.Id == id)
                .FirstOrDefault();
            }
            else
            {
                student = _context.Students.FirstOrDefault(s => s.Id.Equals(id));
            }


            if (student == null)
            {
                return NotFound($"Student {id} was not found");
            }

            return Ok(student);
        }

        [HttpPost]
        public IActionResult Create([FromBody] Students model)
        {

            if (ModelState.IsValid && model != null)
            {
                _context.Add(model);
                _context.SaveChanges();
                return CreatedAtRoute("GetStudents", new { id = model.Id }, model);
            }
            return BadRequest();
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Students model)
        {

            #region other application
            //    if (model == null || model.Id != id)
            //    {
            //        return BadRequest();
            //    }

            //    var student = _context.Students.Find(id);
            //    if (student == null)
            //    {
            //        return NotFound();
            //    }

            //    _context.Students.Update(model);
            //    return new NoContentResult();
            #endregion 

            var students = _context.Students.FirstOrDefault(x => x.Id == id);

            if (students == null)
            {
                return NotFound($"Could not find student with the ID of {id}");

            }
            else
            {
                students.FirstMidName = model.FirstMidName;
                students.LastName = model.LastName ?? students.LastName;
                students.EnrollmentDate = model.EnrollmentDate != DateTime.MinValue ? model.EnrollmentDate : students.EnrollmentDate;
                students.Courses = model.Courses ?? students.Courses;
                students.Age = model.Age != DateTime.MinValue ? model.Age : students.Age;

                _context.SaveChanges();
                return Ok(students);
            }

        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var student = _context.Students.Find(id);

            _context.Students.Remove(student);

            _context.SaveChanges();
            return NoContent();

        }
    }
}
