﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentsCourseStructureApp.Data_Access;
using StudentsCourseStructureApp.Entities;
using System.Linq;

namespace StudentsCourseStructureApp.Controllers
{
    [Route("api/Students/{studentId}/Courses")]
    public class CoursesController : Controller
    {
        private readonly SchoolDbContext _context;
        public CoursesController(SchoolDbContext context)
        {
            _context = context;
        }

        [HttpGet("", Name = "GetCourses")]
        public IActionResult Get(int studentId)
        {
            var courses = _context.Courses.Include(c => c.Students).Include(x => x.Subjects)
                .Where(c => c.Students.Id.Equals(studentId))
                .OrderBy(c => c.Title);

            return Ok(courses);

        }


        [HttpGet("{id}")]
        public IActionResult Get(int studentId, int id)
        {
            var course = _context.Courses.Include(c => c.Students)
                .Where(c => c.Students.Id.Equals(studentId))
                .Include(x => x.Subjects)
                .FirstOrDefault(x => x.Id == id);

            if (course == null)
            {
                return NotFound($"Course {id} was not found");
            }

            if (course.Students.Id != studentId) return BadRequest();
            return Ok(course);
        }

        [HttpPost]
        public IActionResult Create(int studentId, [FromBody] Courses model)
        {

            if (model != null)
            {

                _context.Add(model);
                _context.SaveChanges();
                return CreatedAtRoute("GetCourses", new { id = model.Id }, model);
            }
            return BadRequest("Could not add course");


            #region
            //var students = _context.Students.Where(c => c.Id.Equals(studentId)).FirstOrDefault();

            //if (students == null) return BadRequest("Could not find student");

            //var course = _context.Courses.Add(model);

            //_context.Students.Add(students);
            //_context.SaveChanges();
            //return Created("GetCourses",course);
            #endregion
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Courses model)
        {

            if (model == null || model.Id != id)
            {
                return BadRequest();
            }

            var course = _context.Courses.Find(id);
            if (course == null)
            {
                return NotFound();
            }

            _context.Courses.Update(model);
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var course = _context.Courses.FirstOrDefault(x => x.Id == id);

            _context.Remove(course);
            _context.SaveChanges();


        }
    }
}
