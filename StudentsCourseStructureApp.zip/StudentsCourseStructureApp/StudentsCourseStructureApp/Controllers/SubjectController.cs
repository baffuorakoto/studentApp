﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentsCourseStructureApp.Data_Access;
using StudentsCourseStructureApp.Entities;
using System.Linq;

namespace StudentsCourseStructureApp.Controllers
{
    [Route("api/Students/{studentId}/Courses/{courseId}/subjects")]
    public class SubjectController : Controller
    {
        private readonly SchoolDbContext _context;

        public SubjectController(SchoolDbContext context)
        {
            _context = context;
        }
        public IActionResult Get(int studentId, int courseId)
        {
            var subjects = _context.Subjects
        .Include(c => c.Course)
        .ThenInclude(s => s.Students)
        .Where(c => c.Course.Id == courseId)
        .OrderBy(s => s.SubjectTitle)
        .ToList();

            if (subjects.Any(s => s.Course.Students.Id != studentId)) return BadRequest();

            return Ok(subjects);
        }
        [HttpGet("{id}", Name = "GetSubject")]
        public IActionResult Get(int studentId, int courseId, int id)
        {
            var subject = _context.Subjects
        .Include(c => c.Course)
        .ThenInclude(s => s.Students)
        .Where(s => s.ID == id)
        .OrderBy(s => s.SubjectTitle)
        .FirstOrDefault();

            if (subject.Course.Id != courseId || subject.Course.Students.Id != studentId) return BadRequest();

            return Ok(subject);
        }


        [HttpPost()]
        public IActionResult Post(string studentId, int courseId, [FromBody] Subjects model)
        {
            var course = _context.Courses
                    .Include(s => s.Students)
                    .Where(s => s.Id == courseId)
                    .FirstOrDefault();

            if (course != null)
            {
                var subject = _context.Subjects.Add(model);

                _context.Add(subject);

                _context.SaveChanges();

                return Created(Url.Link("GetSubject", new { studentId, courseId, id = subject }), model);

            }

            return BadRequest("Failed to save new subject");
        }



        [HttpPut("{id}")]
        public IActionResult Put(string studentId, int speakerId, int id, [FromBody] Subjects model)
        {
            var subject = _context.Subjects
          .Include(t => t.Course)
          .ThenInclude(s => s.Students)
          .Where(t => t.ID == id)
          .OrderBy(t => t.SubjectTitle)
          .FirstOrDefault();


            if (subject == null) return NotFound();

            subject.SubjectTitle = model.SubjectTitle;
            subject.Time = model.Time;
            subject.Day = model.Day;

            _context.SaveChanges();
            return Ok(subject);
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(string studentId, int courseId, int id)
        {
            var subject = _context.Subjects
                .Include(t => t.Course)
                .ThenInclude(s => s.Students)
                .Where(t => t.ID == id)
                .OrderBy(t => t.SubjectTitle)
                .FirstOrDefault();

            if (subject == null) return NotFound();

            _context.Remove(subject);

            _context.SaveChanges();

            return NoContent();

        }
    }
}
